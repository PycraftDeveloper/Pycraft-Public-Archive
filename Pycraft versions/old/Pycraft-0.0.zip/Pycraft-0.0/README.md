# Pycraft

This is a project in which I aim to test my abilities and learn new skills, and show what I can do to the community thank you all very much for coming here and I hope you enjoy and are inspired to fire up IDLE yourself.

 - Setup

Please first before you run the program can you make sure that you have all the files downloaded in the attached folder, then please keep them all inside the Pycraft file and don’t move them about inside the folder, as this makes the program crash and we don’t want that eh!

Also I might just add, this program will be compiled hopefully at the end of the development process in December 2021 or later into a .executable ".exe" file, however for now you will need to have python installed on your system, nothing fancy just the IDLE will do, and id recommend Python 3, I’m developing it on Python 3.7.7 although you should be alright with any Python 3 program.

Then please run the installer; "PycraftInstaller.py" this will make sure that all the modules the program needs to run are installed correctly, before you start complaining yes this is a very badly implemented program but it works for now and I do intend to sort this program out.

 - Running the program

Now you have the program properly installed hopefully (you’ll find out if you haven’t promptly!) you need to locate the file "PycraftRunUtil.py" basically all this program does is run the right modules, initiates the main program; "Pycraft.py" and catches any errors that might arise in the program in a nicely rendered error screen, if it crashes on your first run then chances are you haven’t installed the program correctly, if it still doesn’t work then you can drop me an email @ "ThomasJebbo@gmail.com" or comment here on the repository, I do hope however that it works alright for you and you have a pleasant experience. I might also add this program has been developed on a Windows 64-bit computer however should run fine on a 32-bit Windows machine or through MacOS although they remain untested for now. 

I recommend creating a shortcut for the "PycraftRunUtil.py" file too so its easier to locate.

 - Final Notices

Thank you greatly for supporting this project simply by running it, I am sorry in advance for any spelling mistakes. The programs will be updated frequently and I shall do my best to keep this up to date too. I also want to add that you are welcome to view and change the program and share it with your friends however please may I have some credit, just a name would do and if you find any bugs or errors please feel free to comment in the comments section any feedback so I can improve my program, it will all be much appreciated and give as much detail as you wish to give out. BY INSTALLING THIS PROJECT ONTO YOUR COMPUTER AND RUNNING IT I; Tom Jebbo DO NOT TAKE ANY RESPONCIBILITY FOR ANY DAMAGES THIS MAY CAUSE HOWEVER UNLIKELY, AND YOU AGREE TO HAVE EXERNAL MODULES INSTALLED ONTO YOUR COMPUTER ALSO, OF WHICH I HAVE NO CONTROL OVER, PLEASE USE THIS PROGRAM RESPLONCIBLY AND DO NOT USE IT TO CAUSE HARM. YOU MUST ALSO HAVE PERMISSION FROM THE DEVISES MAGAGER OR ADMINISTRATOR TO INSTALL AND USE COMMAND PROMPT OR TERMINAL. NO DATA THIS PROGRAM COLLECTS IS STORED ANYWHERE BUT, ON YOUR DEVISE, AND AT ANY POINT NO CONNECTION TO A NETWORK IS REQUIRED, AFTER INSTALLATION, TO RUN THIS PROGRAM. THIS PROGRAM DOES NOT SEND ANY DATA TO THE DEVELOPER OR ANYONE ELSE ABOUT THIS PROGRAM. Thank you

- credits

With thanks to; <br />
Thomas Jebson <br />
Python 3 @ https://www.bing.com/search?PC=U523&q=python&pglt=299&FORM=ANNTA1# <br />
OpenGL @ https://www.opengl.org/ <br />
Pypi @ https://pypi.org/ <br />
Pillow (PIL) @ https://python-pillow.org/ <br />
Pygame @ https://www.pygame.org <br />
Windows 10 - Visual Studio Code @ https://code.visualstudio.com/ <br />
Freesound: - Erokia's "ambient wave compliation" @ https://freesound.org/s/473545/ <br />
Freesound: - Soundholder's "ambient meadow near forest" @ https://freesound.org/s/425368/ <br />
Blender @ https://www.blender.org/ <br />
