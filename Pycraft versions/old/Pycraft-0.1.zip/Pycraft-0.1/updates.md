- Our update policy

New releases will be introduced regularly, it is likely that there will be some form of error or bug, therefore unless you intend to use this project for development and feedback purposes (Thank you all!) we recomend you use the latest stable release; below is how to identify the stable releases.

- Version naming

Our individual versions is labeled individually following the format below:
eg: 21p1003-21a
This is (Date), (First letter of name of game), (Big release ID), (Month), (-), (Year), (Alpha/Beta)
Any Unstable releases will also have in addition to the following format, a release code at the end, starting from 01, these indicate how many new revisioons there have been before the last large update.

Thank you.
