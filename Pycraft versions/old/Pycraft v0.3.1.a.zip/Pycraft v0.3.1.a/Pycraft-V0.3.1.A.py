import pygame
import numpy
import math
import random
import os
import sys
import time
import PIL

pygame.init()

while True:

    display_X = 250
    display_Y = 250
    pygame.display.set_mode((display_X,display_Y))

    for event in pygame.event.get():
        if (event.type == pygame.KEYDOWN):
            if (event.key == pygame.K_ESCAPE) or (event.type == pygame.QUIT):
                pygame.quit()
                print("We hoped you enjoyed playing Pycraft")
                quit()